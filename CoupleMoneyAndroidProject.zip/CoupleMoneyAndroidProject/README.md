# Couple Money Android project

A minimal Android WebView wrapper around the supplied Couple Money HTML app.

## Build with GitHub Actions
1. Upload the contents of this ZIP into the root of your GitHub repository (keep `.github/workflows/build-apk.yml` and `app/` in the repository root).
2. Open the **Actions** tab and run **Build Couple Money APK** (or push a commit to `main`/`master`).
3. When the run succeeds, download the `couple-money-debug-apk` artifact.

APK output: `app/build/outputs/apk/debug/app-debug.apk`
